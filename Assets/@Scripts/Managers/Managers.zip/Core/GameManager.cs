using UnityEngine;

public class GameManager : PersistentMonoSingleton<GameManager>
{
    [Header("Core Managers")]
    [SerializeField] private SceneFlowManager _sceneFlowManager;
    [SerializeField] private InputManager _inputManager;

    protected override void OnInitialized()
    {
        base.OnInitialized();

        RegisterManagers();
        InitializeManagers();

        Debug.Log("GameManager Initialized");
    }

    private void RegisterManagers()
    {
        if (_sceneFlowManager == null)
        {
            Debug.LogError("SceneFlowManager is not assigned!");
            return;
        }

        if (_inputManager == null)
        {
            Debug.LogError("InputManager is not assigned!");
            return;
        }

        ManagerRegistry.Register<GameManager>(this);
        ManagerRegistry.Register<SceneFlowManager>(_sceneFlowManager);
        ManagerRegistry.Register<InputManager>(_inputManager);
    }

    private void InitializeManagers()
    {
        Initialize(_inputManager);
        Initialize(_sceneFlowManager);
    }

    private void Initialize(IInitializable manager)
    {
        if (manager == null) return;

        if (!manager.IsInitialized)
            manager.Initialize();
    }

    public void StartGame()
    {
        if (_sceneFlowManager == null)
        {
            Debug.LogError("SceneFlowManager is missing!");
            return;
        }

        Debug.Log("Game Start!");
        _sceneFlowManager.LoadStage("Stage_01");
    }
}