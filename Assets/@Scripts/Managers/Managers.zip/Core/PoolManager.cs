using System.Collections.Generic;
using UnityEngine;

public class PoolManager : MonoBehaviour, IInitializable
{
    public bool IsInitialized { get; private set; }

    private readonly Dictionary<GameObject, Queue<GameObject>> _pools = new();
    private readonly Dictionary<GameObject, GameObject> _instanceToPrefab = new();

    public void Initialize()
    {
        if (IsInitialized) return;
        IsInitialized = true;
    }

    public void CreatePool(GameObject prefab, int initialSize)
    {
        if (prefab == null || initialSize <= 0)
            return;

        if (!_pools.ContainsKey(prefab))
            _pools[prefab] = new Queue<GameObject>();

        for (int i = 0; i < initialSize; i++)
        {
            GameObject instance = CreateNewInstance(prefab);
            ReturnInternal(prefab, instance);
        }
    }

    public GameObject Get(GameObject prefab, Vector3 position, Quaternion rotation)
    {
        if (prefab == null)
        {
            Debug.LogError("[PoolManager] Prefab is null.");
            return null;
        }

        if (!_pools.ContainsKey(prefab))
            _pools[prefab] = new Queue<GameObject>();

        GameObject instance;

        if (_pools[prefab].Count > 0)
        {
            instance = _pools[prefab].Dequeue();
        }
        else
        {
            instance = CreateNewInstance(prefab);
        }

        instance.transform.SetPositionAndRotation(position, rotation);
        instance.SetActive(true);

        return instance;
    }

    public void Return(GameObject instance)
    {
        if (instance == null)
            return;

        if (!_instanceToPrefab.TryGetValue(instance, out GameObject prefab))
        {
            Debug.LogWarning("[PoolManager] Returned object was not created by PoolManager. Destroying it.");
            Destroy(instance);
            return;
        }

        ReturnInternal(prefab, instance);
    }

    private GameObject CreateNewInstance(GameObject prefab)
    {
        GameObject instance = Instantiate(prefab);
        _instanceToPrefab[instance] = prefab;
        return instance;
    }

    private void ReturnInternal(GameObject prefab, GameObject instance)
    {
        instance.SetActive(false);

        if (!_pools.ContainsKey(prefab))
            _pools[prefab] = new Queue<GameObject>();

        _pools[prefab].Enqueue(instance);
    }
}