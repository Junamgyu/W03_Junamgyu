using UnityEngine;

public class Laser : MonoBehaviour
{
    [SerializeField] private Transform _muzzle;     // �ѱ� ��ġ
    [SerializeField] private LayerMask _blockLayer; // ������ ���� ���̾� (Ground, Enemy ��)

    LineRenderer _laser;
    Player _player;


    void Start()
    {
        _laser = GetComponent<LineRenderer>();
        _player = GetComponentInParent<Player>();
    }

    void Update()
    {
        Vector2 aimDir = _player.playerAimer.AimDirection;

        _laser.SetPosition(0, _muzzle.position);

        RaycastHit2D hit = Physics2D.Raycast(_muzzle.position, aimDir, 20f, _blockLayer);
        if (hit.collider != null)
            _laser.SetPosition(1, hit.point);
        else
            _laser.SetPosition(1, (Vector2)_muzzle.position + aimDir * 20f);
    }
}
